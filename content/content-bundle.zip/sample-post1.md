---
title: Sample Post 1
description: Meta description for Sample Post 1
canonical: https://markbase-template-blog.vercel.app
ogUrl: https://markbase-template-blog.vercel.app
ogTitle: Sample Post 1 OG Title
ogDescription: Sample Post 1 OG Description
ogImage: https://images.unsplash.com/photo-1651672263604-fb502b92f6fe?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=465&q=80
ogSitename: Markbase Template Blog
twitterHandle: "@markbasedev"
twitterSite: "@markbasedev"
twitterCardType: summary_large_image
---

# Sample Post 1

[Sample Post 2](./sample-post2.md)

[Sample Child Post 2](./sample-folder/sample-child-post2.md)

[Sample External Link](https://tressel.xyz)

## H2
### H3
#### H4